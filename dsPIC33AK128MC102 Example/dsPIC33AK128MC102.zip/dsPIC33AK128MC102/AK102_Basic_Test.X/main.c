/*
? [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/timer/delay.h"
#include "mcc_generated_files/system/pins.h"
#include "OLED128x64.h"
#include "mcc_generated_files/i2c_host/i2c2.h"
#include "mcc_generated_files/adc/adc1.h"
#include <stdio.h>
#include <string.h>

uint8_t     ASCII_Buffer[32];
/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    ADC1_Enable();
    DELAY_milliseconds(200);
    
    
        OLED_Init();      
        OLED_CLS(); 
        OLED_Put8x16Str(0,0," dsPIC33AK128MC");
        OLED_Put8x16Str(0,2,"I am 32-bit DSC"); 

    while(1)
    {
        DELAY_milliseconds(200);
        PWM1_Toggle();
        
        ADC1_SoftwareTriggerEnable();
        while (!ADC1_IsConversionComplete( ADC1_Channel0 ))
        {;}
                    sprintf (ASCII_Buffer,"ADC = %4d ", ADC1_ConversionResultGet(ADC1_Channel0)) ;
                    OLED_Put8x16Str(0,4,(uint8_t*)ASCII_Buffer) ;  
                    printf("Hello .. dsPIC33AK \n\r" );
    }    
}